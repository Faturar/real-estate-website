

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3 m-0">Rumah Dijual</h4>
      <div>
        <a href="<?php echo e(route('rumah-dijual.create')); ?>" class="btn btn-primary"><i class='bx bx-plus' ></i> Tambah</a>
      </div> 
    </div>

    <!-- Basic Bootstrap Table -->
    <div class="card">
      <h5 class="card-header">Data Rumah Dijual</h5>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Image</th>
              <th>Harga Cash</th>
              <th>Harga DP</th>
              <th>Tipe</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <?php $__empty_1 = true; $__currentLoopData = $rumah_dijuals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rumah_dijual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($rumah_dijual->name); ?></td>
                <td class="w-25">
                  <img class="img-thumbnail" src="<?php echo e(Storage::url($rumah_dijual->image)); ?>" alt="">
                </td>
                <td><?php echo e($rumah_dijual->harga_cash); ?> JT</td>
                <td><?php echo e($rumah_dijual->harga_dp); ?> JT</td>
                <td><?php echo e($rumah_dijual->tipe); ?></td>
                <td>
                  <span class="badge bg-label-primary me-1"><?php echo e($rumah_dijual->status); ?></span>
                </td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="<?php echo e(route('rumah-dijual.show', $rumah_dijual->id)); ?>"
                        ><i class='bx bx-info-circle me-1'></i> Detail</a
                      >
                      <a class="dropdown-item" href="<?php echo e(route('rumah-dijual.edit', $rumah_dijual->id)); ?>"
                        ><i class="bx bx-edit-alt me-1"></i> Edit</a
                      >
                      <form action="<?php echo e(route('rumah-dijual.destroy', $rumah_dijual->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>;
                        
                        <button type="submit" class="dropdown-item">
                          <i class="bx bx-trash me-1"></i> 
                          Delete
                        </button>
                      </form>
                    </div>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr class="text-center">
                <td colspan="6">Tidak Ada Data</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/rumah-dijual/index.blade.php ENDPATH**/ ?>