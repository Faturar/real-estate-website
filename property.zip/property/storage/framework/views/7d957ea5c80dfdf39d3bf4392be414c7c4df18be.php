

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3 mb-4">Informasi Website</h4>
      <div>
        <a href="<?php echo e(route('informasi.edit', 1)); ?>" class="btn btn-primary"><i class='bx bx-edit'></i> Edit</a>
      </div>
    </div>

    <div class="row flex-lg-row-reverse">
      <div class="col-12 col-lg-4">
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Logo</h5>
          </div>
          <div class="card-body">
            <img class="img-fluid" src="<?php echo e(Storage::url($informasi->logo)); ?>" alt="">
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-8">
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Data Informasi Website</h5>
          </div>
          <div class="card-body">
            <!-- Basic Bootstrap Table -->
            <div class="card">
              <h5 class="card-header">Dasar</h5>
              <table class="table">
                <tr>
                  <th>Title</th>
                  <td class="w-75"><?php echo e($informasi->title); ?></td>
                </tr>
                <tr>
                  <th>Short Description</th>
                  <td><?php echo e($informasi->short_description); ?></td>
                </tr>
              </table>
              <h5 class="card-header">Contact</h5>
              <table class="table">
                <tr>
                  <th>No Telepon</th>
                  <td class="w-75"><?php echo e($informasi->no_telepon); ?></td>
                </tr>
                <tr>
                  <th>Email</th>
                  <td><?php echo e($informasi->email); ?></td>
                </tr>
                <tr>
                  <th>Alamat</th>
                  <td><?php echo e($informasi->alamat); ?></td>
                </tr>
                <tr>
                  <th>Google Maps Link</th>
                  <td><?php echo e($informasi->gmaps_link); ?></td>
                </tr>
              </table>
            </div>
            <!--/ Basic Bootstrap Table -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/informasi/index.blade.php ENDPATH**/ ?>