

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Rumah Dijual /</span> Detail</h4>
    </div>

    <div class="row flex-lg-row-reverse">
      <div class="col-12 col-lg-4">
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Gambar</h5>
          </div>
          <div class="card-body">
            <img class="img-fluid" src="<?php echo e(Storage::url($rumah_dijual->image)); ?>" alt="">
          </div> 
        </div>
      </div>
      <div class="col-12 col-lg-8">
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Rumah <span class="badge bg-label-primary ms-1"><?php echo e($rumah_dijual->status); ?></span></h5>
          </div>
          <div class="card-body">
            <!-- Basic Bootstrap Table -->
            <div class="card">
              <h5 class="card-header">Data Rumah Dijual</h5>
              <div class="table-responsive text-nowrap">
                <table class="table">
                  <tr>
                    <th>Name</th>
                    <td><?php echo e($rumah_dijual->name); ?></td>
                  </tr>
                  <tr>
                    <th>Tipe</th>
                    <td><?php echo e($rumah_dijual->tipe); ?></td>
                  </tr>
                  <tr>
                    <th>Ukuran Tanah</th>
                    <td><?php echo e($rumah_dijual->ukuran_tanah); ?></td>
                  </tr>
                  <tr>
                    <th>Lokasi</th>
                    <td><?php echo e($rumah_dijual->lokasi); ?></td>
                  </tr>
                  <tr>
                    <th>Kamar Tidur</th>
                    <td><?php echo e($rumah_dijual->kamar_tidur); ?></td>
                  </tr>
                  <tr>
                    <th>Kamar Mandi</th>
                    <td><?php echo e($rumah_dijual->kamar_mandi); ?></td>
                  </tr>
                  <tr>
                    <th>Harga Cash</th>
                    <td><?php echo e($rumah_dijual->harga_cash); ?></td>
                  </tr>
                  <tr>
                    <th>Harga DP</th>
                    <td><?php echo e($rumah_dijual->harga_dp); ?></td>
                  </tr>
                  <tr>
                    <th>Deskripsi</th>
                    <td><?php echo e($rumah_dijual->description); ?></td>
                  </tr>
                </table>
              </div>
            </div>
            <!--/ Basic Bootstrap Table -->
          </div>
        </div>
      </div>
      
    </div>
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/rumah-dijual/detail.blade.php ENDPATH**/ ?>