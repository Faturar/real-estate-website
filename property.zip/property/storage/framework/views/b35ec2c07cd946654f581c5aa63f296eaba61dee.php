<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('frontend/lib/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/lib/waypoints/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

<!-- Template Javascript -->
<script src="<?php echo e(url('frontend/js/main.js')); ?>"></script><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/includes/script.blade.php ENDPATH**/ ?>