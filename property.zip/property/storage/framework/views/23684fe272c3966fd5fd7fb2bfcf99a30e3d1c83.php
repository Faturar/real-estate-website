

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3 m-0">Tipe Rumah</h4>
      <div>
        <a href="<?php echo e(route('tipe-rumah.create')); ?>" class="btn btn-primary"><i class='bx bx-plus' ></i> Tambah</a>
      </div>
      
    </div>

    <!-- Basic Bootstrap Table -->
    <div class="card">
      <h5 class="card-header">Data Tipe Rumah</h5>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Icon</th>
              <th>Dekripsi</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <?php $__empty_1 = true; $__currentLoopData = $tipe_rumahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tipe_rumah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($key + 1); ?></td>
                <td class="w-25"><?php echo e($tipe_rumah->name); ?></td>
                <td><img class="w-px-100" src="<?php echo e(Storage::url($tipe_rumah->icon)); ?>" alt=""></td>
                <td class="w-25"><?php echo e($tipe_rumah->deskripsi); ?></td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="<?php echo e(route('tipe-rumah.edit', $tipe_rumah->id)); ?>"
                        ><i class="bx bx-edit-alt me-1"></i> Edit</a
                      >
                      <form action="<?php echo e(route('tipe-rumah.destroy', $tipe_rumah->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        
                        <button type="submit" class="dropdown-item"
                          ><i class="bx bx-trash me-1"></i> Delete</button
                        >
                      </form>
                    </div>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr class="text-center">
                <td colspan="6">Tidak Ada Data</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/tipe-rumah/index.blade.php ENDPATH**/ ?>