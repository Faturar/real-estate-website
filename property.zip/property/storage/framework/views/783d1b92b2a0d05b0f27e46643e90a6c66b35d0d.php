

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3"><span class="text-muted fw-light">Message /</span> Detail</h4>
    </div>

    <div class="card">
      <h5 class="card-header">Detail Message</h5>
      <div class="table-responsive">
        <table class="table">
          <tr>
            <th class="w-25">Name</th>
            <td><?php echo e($message->name); ?></td>
          </tr>
          <tr>
            <th>Email</th>
            <td><?php echo e($message->email); ?></td>
          </tr>
          <tr>
            <th>Subject</th>
            <td><?php echo e($message->subject); ?></td>
          </tr>
          
          <tr>
            <th>Waktu</th>
            <td><?php echo e($message->created_at); ?></td>
          </tr>
          <tr>
            <th>Message</th>
            <td><?php echo e($message->message); ?></td>
          </tr>
        </table>
      </div>
    </div>
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/message/detail.blade.php ENDPATH**/ ?>