

<?php $__env->startSection('title'); ?>
    Informasi Perumahan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Tipe Rumah /</span> Edit</h4>
    </div>

    <form action="<?php echo e(route('tipe-rumah.update', $tipe_rumah->id)); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <div class="row flex-lg-row-reverse">
        <div class="col-12 col-lg-4">
          <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h5 class="mb-0">Gambar</h5>
            </div>
            <div class="card-body">
              <img src="<?php echo e(Storage::url($tipe_rumah->icon)); ?>" alt="<?php echo e($tipe_rumah->name); ?>">
              <div class="mb-3">
                <label for="formFile" class="form-label text-danger">Jangan diubah jika tidak ingin mengedit</label>
                <input class="form-control" name="icon" type="file" id="formFile" />
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-8">
          <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h5 class="mb-0">Tipe Rumah</h5>
            </div>
            <div class="card-body">
              <form>
                <div class="mb-3">
                  <label class="form-label" for="name">Name</label>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="<?php echo e($tipe_rumah->name); ?>" />
                </div>
                <div class="mb-3">
                  <label class="form-label" for="deskripsi">Deskripsi</label>
                  <textarea type="text" name="deskripsi" class="form-control" id="deskripsi" placeholder="Deskripsi"><?php echo e($tipe_rumah->deskripsi); ?></textarea>
                </div>
                  
                <button type="submit" class="btn btn-primary">Edit</button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fatur\Documents\GitHub\Property\property\resources\views/pages/admin/tipe-rumah/edit.blade.php ENDPATH**/ ?>